#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <string.h>
#include <stdio.h>

//Prototypes
void Fenetre_accueil(SDL_Renderer *);
void Fentre_option(SDL_Renderer *,int );
void Fenetre_regles(SDL_Renderer *);
void Fentre_niveau(SDL_Renderer *);
void Fenetre_Niveau1(SDL_Renderer *);
void Fenetre_Niveau2(SDL_Renderer *);
void Fenetre_Niveau3(SDL_Renderer *);
void Quitter(SDL_Window *accueil,SDL_Renderer *,SDL_Renderer *,SDL_Renderer *,SDL_Renderer *,SDL_Renderer *,SDL_Renderer *);
void Image(SDL_Renderer *,SDL_Surface *,int ,int ,int ,int );
void Musique();
void Fscore(int );
//Var Globales
SDL_Event event;

/*************************************************** FONCTIONS ***************************************************/

void Fenetre_accueil(SDL_Renderer *FondEcran_accueil)
{
	SDL_Surface *jouer = NULL;
	SDL_Surface *option = NULL;
	SDL_Surface *quitter = NULL;
	SDL_Surface *bateau = NULL;
	SDL_Surface *pirate1 = NULL;
	SDL_Surface *pirate2 = NULL;
	
	jouer=SDL_LoadBMP(".\\img\\fond\\Start.bmp");
	option=SDL_LoadBMP(".\\img\\fond\\Option.bmp");
	quitter=SDL_LoadBMP(".\\img\\fond\\Quitter.bmp");
	bateau=SDL_LoadBMP(".\\img\\fond\\bateau.bmp");
	pirate1=SDL_LoadBMP(".\\img\\fond\\pirate.bmp");
	pirate2=SDL_LoadBMP(".\\img\\fond\\pirate1.bmp");
	
	Image(FondEcran_accueil,jouer,250,110,300,87);		   
	Image(FondEcran_accueil,option,250,306,300,87);
	Image(FondEcran_accueil,quitter,250,502,300,87);
	Image(FondEcran_accueil,bateau,25,50,200,192);
	Image(FondEcran_accueil,pirate1,550,276,250,138);
	Image(FondEcran_accueil,pirate2,0,475,250,166);
	Image(FondEcran_accueil,SDL_LoadBMP(".\\img\\fond\\credit.bmp"),96,642,607,44);
}

void Fenetre_option(SDL_Renderer *FondEcran_option,int imgson)
{
	SDL_Surface *menu = NULL;
	SDL_Surface *bateau = NULL;
	SDL_Surface *pirate1 = NULL;
	SDL_Surface *pirate2 = NULL;
	SDL_Surface *son = NULL;
	SDL_Surface *son1 = NULL;
	SDL_Surface *regles = NULL;
	
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	bateau=SDL_LoadBMP(".\\img\\fond\\bateau.bmp");
	pirate1=SDL_LoadBMP(".\\img\\fond\\pirate.bmp");
	pirate2=SDL_LoadBMP(".\\img\\fond\\pirate1.bmp");
	son=SDL_LoadBMP(".\\img\\fond\\Son.bmp");
	son1=SDL_LoadBMP(".\\img\\fond\\son1.bmp");
	regles=SDL_LoadBMP(".\\img\\fond\\Regles.bmp");

	Image(FondEcran_option,menu,50,50,250,71);		   
	Image(FondEcran_option,bateau,500,20,200,192);
	Image(FondEcran_option,pirate1,550,525,250,138);
	Image(FondEcran_option,pirate2,0,525,250,166);
	Image(FondEcran_option,son,175,261,300,85);
	Image(FondEcran_option,regles,250,427,300,85);
	if (imgson==0)
	{
		Image(FondEcran_option,son1,525,261,100,85);
	}
}

void Fenetre_regles(SDL_Renderer *FondEcran_regles)
{
	SDL_Surface *menu = NULL;
	SDL_Surface *bateau = NULL;
	SDL_Surface *pirate1 = NULL;
	SDL_Surface *pirate2 = NULL;
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	bateau=SDL_LoadBMP(".\\img\\fond\\bateau.bmp");
	pirate1=SDL_LoadBMP(".\\img\\fond\\pirate.bmp");
	pirate2=SDL_LoadBMP(".\\img\\fond\\pirate1.bmp");

	Image(FondEcran_regles,menu,50,50,250,71);		   
	Image(FondEcran_regles,bateau,500,20,200,192);
	Image(FondEcran_regles,pirate1,550,475,250,138);
	Image(FondEcran_regles,pirate2,0,475,250,166);
	Image(FondEcran_regles,SDL_LoadBMP(".\\img\\fond\\regles2.bmp"),103,257,593,185);
}

void Fenetre_niveau(SDL_Renderer *FondEcran_niveau)
{
	SDL_Surface *menu = NULL;
	SDL_Surface *niv1 = NULL;
	SDL_Surface *niv2 = NULL;
	SDL_Surface *niv3 = NULL;
	SDL_Surface *bateau = NULL;
	SDL_Surface *pirate1 = NULL;
	SDL_Surface *pirate2 = NULL;
	menu = SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	niv1 = SDL_LoadBMP(".\\img\\fond\\Niv_1.bmp");
	niv2 = SDL_LoadBMP(".\\img\\fond\\Niv_2.bmp");
	niv3 = SDL_LoadBMP(".\\img\\fond\\Niv_3.bmp");
	bateau=SDL_LoadBMP(".\\img\\fond\\bateau.bmp");
	pirate1=SDL_LoadBMP(".\\img\\fond\\pirate.bmp");
	pirate2=SDL_LoadBMP(".\\img\\fond\\pirate1.bmp");
	
	
	Image(FondEcran_niveau,menu,50,50,250,71);
	Image(FondEcran_niveau,niv1,50,231,300,86);
	Image(FondEcran_niveau,niv2,450,231,300,85);
	Image(FondEcran_niveau,niv3,250,427,300,86);	
	Image(FondEcran_niveau,bateau,500,20,200,192);
	Image(FondEcran_niveau,pirate1,550,475,250,138);
	Image(FondEcran_niveau,pirate2,0,475,250,166);
	
}


void Fenetre_Niveau1(SDL_Renderer *FondEcran_niveau1)
{
	SDL_Surface *menu = NULL,*piece1 = NULL,*piece2 = NULL,*piece3 = NULL,*piece4 = NULL,*piece5 = NULL,*piece6 = NULL,*piece7 = NULL,*piece8 = NULL,*piece9 = NULL;
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	piece1=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc1.bmp");
	piece2=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc2.bmp");
	piece3=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc3.bmp");
	piece4=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc4.bmp");
	piece5=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc5.bmp");
	piece6=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc6.bmp");
	piece7=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc7.bmp");
	piece8=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc8.bmp");
	piece9=SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc9.bmp");
	
	Image(FondEcran_niveau1,menu,50,50,250,71);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectniv1.bmp"),824,23,253,161);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\reponse1.bmp"),826,25,249,157);
	Image(FondEcran_niveau1,piece1,365,70,166,105);
	Image(FondEcran_niveau1,piece2,150,700,166,105);
	Image(FondEcran_niveau1,piece3,866,340,166,105);
	Image(FondEcran_niveau1,piece4,750,740,166,105);
	Image(FondEcran_niveau1,piece5,585,90,166,105);
	Image(FondEcran_niveau1,piece6,66,225,166,105);
	Image(FondEcran_niveau1,piece7,66,445,166,105);
	Image(FondEcran_niveau1,piece8,450,660,166,105);
	Image(FondEcran_niveau1,piece9,866,560,166,105);
	
	
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),298,276,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),467,276,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),636,276,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),298,384,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),467,384,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),636,384,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),298,492,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),467,492,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rect.bmp"),636,492,166,105);	   
	
}

void Fenetre_Niveau2(SDL_Renderer *FondEcran_niveau2)
{
	SDL_Surface *menu = NULL;
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	
	Image(FondEcran_niveau2,menu,50,50,250,71);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectniv2.bmp"),831,20,248,161);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\reponse2.bmp"),833,22,244,157);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc1.bmp"),350,660,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc2.bmp"),87,187,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc3.bmp"),600,165,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc4.bmp"),87,624,124,80);
	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc5.bmp"),87,479,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc6.bmp"),890,485,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc7.bmp"),650,30,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc8.bmp"),350,165,124,80);
	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc9.bmp"),400,30,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc10.bmp"),150,770,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc11.bmp"),750,740,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc12.bmp"),890,340,124,80);
	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc13.bmp"),890,195,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc14.bmp"),87,333,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc15.bmp"),900,630,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc16.bmp"),550,700,124,80);

	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),298,286,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),425,286,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),552,286,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),679,286,124,80);
	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),298,369,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),425,369,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),552,369,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),679,369,124,80);
	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),298,452,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),425,452,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),552,452,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),679,452,124,80);	
	
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),298,535,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),425,535,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),552,535,124,80);
	Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rect.bmp"),679,535,124,80);		   
}

void Fenetre_Niveau3(SDL_Renderer *FondEcran_niveau3)
{
	SDL_Surface *menu = NULL;
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	
	Image(FondEcran_niveau3,menu,50,50,250,71);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc1.bmp"),400,30,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc2.bmp"),150,770,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc3.bmp"),890,340,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc4.bmp"),750,740,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc5.bmp"),890,195,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc6.bmp"),87,624,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc7.bmp"),900,630,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc8.bmp"),550,700,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc9.bmp"),350,660,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc10.bmp"),87,187,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc11.bmp"),600,100,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc12.bmp"),87,333,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc13.bmp"),87,479,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc14.bmp"),890,485,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc15.bmp"),800,50,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc16.bmp"),350,165,124,80);
	
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,286,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,286,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,286,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,286,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,369,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,369,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,369,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,369,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,452,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,452,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,452,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,452,124,80);	
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,535,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,535,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,535,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,535,124,80);	
}

void Quitter(SDL_Window *accueil,SDL_Renderer *FondEcran_accueil,SDL_Renderer *FondEcran_option,SDL_Renderer *FondEcran_niveau,SDL_Renderer *FondEcran_niveau1,SDL_Renderer *FondEcran_niveau2,SDL_Renderer *FondEcran_niveau3)
{
	SDL_DestroyRenderer(FondEcran_accueil);
	SDL_DestroyRenderer(FondEcran_option);
	SDL_DestroyRenderer(FondEcran_niveau);
	SDL_DestroyRenderer(FondEcran_niveau1);
	SDL_DestroyRenderer(FondEcran_niveau2);
	SDL_DestroyRenderer(FondEcran_niveau3);
	SDL_DestroyWindow(accueil);
}

void Image(SDL_Renderer *FondEcran,SDL_Surface *pic,int x,int y,int largeur,int hauteur)
{
	SDL_Rect rect,rst;
	SDL_Texture *tex = NULL;
	
	
	tex = SDL_CreateTextureFromSurface(FondEcran, pic);
	SDL_FreeSurface(pic);
	rect.x = x;//position de l'image en x sur la fenetre
	rect.y = y;//position de l'image en y sur la fenetre
	
	SDL_QueryTexture(tex, NULL, NULL, &rect.w, &rect.h);

	rst.x=0; // pour afficher l'image à partir de son abscisse x=0
	rst.y=0; // pour afficher l'image à partir de son ordonnee y=0
	rst.w=largeur;
	rst.h=hauteur;
		
	SDL_RenderCopy(FondEcran, tex, &rst, &rect);
				   
	SDL_RenderPresent(FondEcran);//on pose  sur la fenetre
}

void Musique()
{
	Mix_Music *music;
	music=Mix_LoadMUS(".\\son\\Pirates_des_Caraibes.ogg");
	Mix_PlayMusic(music,-1);//-1 sert a faire boucler la musique
}
/*
void Fscore (int score)
{
	
}*/

/*************************************************** MAIN ***************************************************/
int main(int argc, char** argv)
{
	int continuer=1,musique=0,imgson=0,score=0;
	int piece1=0,piece2=0,piece3=0,piece4=0,piece5=0,piece6=0,piece7=0,piece8=0,piece9=0,piece10=0,piece11=0,piece12=0,piece13=0,piece14=0,piece15=0,piece16=0,fin=0;
	SDL_Window *accueil = NULL, *option = NULL, *regles=NULL, *niveau = NULL, *Niveau1 = NULL, *Niveau2 = NULL, *Niveau3 = NULL;
	SDL_Renderer *FondEcran_accueil = NULL, *FondEcran_option=NULL, *FondEcran_regles=NULL, *FondEcran_niveau=NULL, *FondEcran_niveau1=NULL, *FondEcran_niveau2=NULL, *FondEcran_niveau3=NULL;
	
	fprintf(stdout,"argc=%d",argc);
	fprintf(stdout,"argv=%s",argv[0]);
	if (SDL_Init(SDL_INIT_VIDEO) != 0 )
    {
        fprintf(stdout,"Échec de l'initialisation de la SDL (%s)\n",SDL_GetError());
        return -1;
    }
	
	if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1) //Initialisation de l'API Mixer
    {
      fprintf(stdout, "\nEreur d'initialisation de SDL2 MIXER : %s", Mix_GetError());
      SDL_Quit();
      return -2;

	} 
	/******** Déclaration des fenêtres ********/
	accueil = SDL_CreateWindow("LE1_MPI_2017_ Quettier_Masson -- Allez c'est parti pour un puzzle :D ",
								SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
								SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
								800,// largeur de la fenetre
								700,// hauteur de la fenetre
								SDL_WINDOW_SHOWN); //ouverture de la fenetre
	
	option=SDL_CreateWindow("Option",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 800,
							 700,
							 SDL_WINDOW_HIDDEN); 
	
	regles=SDL_CreateWindow("Règles du jeu",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 800,
							 700,
							 SDL_WINDOW_HIDDEN); 
	
	niveau=SDL_CreateWindow("Niveaux",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 800,
							 700,
							 SDL_WINDOW_HIDDEN); 
	
	Niveau1=SDL_CreateWindow("Puzzle Niveau 1",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  1100,
							  900,
							  SDL_WINDOW_HIDDEN);
							
	Niveau2=SDL_CreateWindow("Puzzle Niveau 2",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  1100,
							  900,
							  SDL_WINDOW_HIDDEN);
							
	Niveau3=SDL_CreateWindow("Puzzle Niveau 3",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  1100,
							  900,
							  SDL_WINDOW_HIDDEN); 
	
	/******** Déclaration des renderer ********/
	FondEcran_accueil = SDL_CreateRenderer(accueil, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	FondEcran_option = SDL_CreateRenderer(option, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	FondEcran_regles = SDL_CreateRenderer(regles, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	FondEcran_niveau = SDL_CreateRenderer(niveau, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	FondEcran_niveau1 = SDL_CreateRenderer(Niveau1, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	FondEcran_niveau2 = SDL_CreateRenderer(Niveau2, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	FondEcran_niveau3 = SDL_CreateRenderer(Niveau3, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
		
	
    Fenetre_accueil(FondEcran_accueil);
	Musique();
	while(continuer==1)
	{
		SDL_WaitEvent(&event);
       	switch (event.type) /* Quel événement avons-nous ? */
        {	
			case SDL_MOUSEBUTTONDOWN:
				if(event.button.windowID == 1)//accueil(fenetre)
				//les id c'est par rapport a l'ordre de creation des fenetres
				{
					//PLAY
					if (event.button.x >=250 && event.button.x <=550 && event.button.y>=110 && event.button.y <=197)
					{
						fprintf( stdout,"\nSTART");
						SDL_HideWindow(accueil);
						SDL_ShowWindow(niveau);
						Fenetre_niveau(FondEcran_niveau);
					}
					//OPTION
					if (event.button.x >=250 && event.button.x <=550 && event.button.y>=306 && event.button.y <=393)
					{
						fprintf( stdout,"\nOPTION");
						SDL_HideWindow(accueil);
						SDL_ShowWindow(option);
						Fenetre_option(FondEcran_option,imgson);
						imgson=1;
					}
					//QUITTER
					if (event.button.x >=250 && event.button.x <=550 && event.button.y>=502 && event.button.y <=589)
					{
						fprintf( stdout,"\nQUITTER");
						Quitter(accueil,FondEcran_accueil,FondEcran_option,FondEcran_niveau,FondEcran_niveau1,FondEcran_niveau2,FondEcran_niveau3);
						continuer=2;
					}
				}
				
				if(event.button.windowID == 2)//option(fenetre)
				{
					//MENU
					if (event.button.x >=50 && event.button.x <=300 && event.button.y>=50 && event.button.y <=121)
					{
						fprintf( stdout,"\nMENU");
						SDL_HideWindow(option);
						SDL_ShowWindow(accueil);
						Fenetre_accueil(FondEcran_accueil);
					}
					//SON
					if(event.button.x >=175 && event.button.x <=625 && event.button.y>=261 && event.button.y <=347)
					{
						fprintf( stdout,"\nSON");
						if(musique==1)
						{
							musique=0;
							Fenetre_option(FondEcran_option,imgson);
							Image(FondEcran_option,SDL_LoadBMP(".\\img\\fond\\son1.bmp"),525,261,100,85);
							Mix_ResumeMusic();
						}
						else
						{
							musique=1;
							Fenetre_option(FondEcran_option,imgson);
							Image(FondEcran_option,SDL_LoadBMP(".\\img\\fond\\son2.bmp"),525,261,100,85);
							Mix_PauseMusic();
						}
					}
					//REGLES
					if(event.button.x >=250 && event.button.x <=550 && event.button.y>=427 && event.button.y <=513)
					{
						fprintf(stdout,"\nREGLES");
						SDL_HideWindow(option);
						SDL_ShowWindow(regles);
						Fenetre_regles(FondEcran_regles);
					}
				}
				
				if(event.button.windowID == 3)//regles(fenetre)
				{
					//MENU
					if (event.button.x >=50 && event.button.x <=300 && event.button.y>=50 && event.button.y <=121)
					{
						fprintf( stdout,"\nMENU");
						SDL_HideWindow(regles);
						SDL_ShowWindow(accueil);
						Fenetre_accueil(FondEcran_accueil);
					}
				}
				
				if(event.button.windowID == 4)//niveau(fenetre)
				{
					//MENU
					if (event.button.x >=50 && event.button.x <=300 && event.button.y>=50 && event.button.y <=121)
					{
						fprintf( stdout,"\nMENU");
						SDL_HideWindow(niveau);
						SDL_ShowWindow(accueil);
						Fenetre_accueil(FondEcran_accueil);
					}
					//Niv.1
					if (event.button.x >=50 && event.button.x <=350 && event.button.y>=231 && event.button.y <=317)
					{
						fprintf( stdout,"\nNiv 1");
						SDL_HideWindow(niveau);
						SDL_ShowWindow(Niveau1);
						Fenetre_Niveau1(FondEcran_niveau1);
					}
					//Niv.2
					if (event.button.x >=450 && event.button.x <=750 && event.button.y>=231 && event.button.y <=316)
					{
						fprintf( stdout,"\nNiv 2");
						SDL_HideWindow(niveau);
						SDL_ShowWindow(Niveau2);
						Fenetre_Niveau2(FondEcran_niveau2);
					}
					//Niv.3
					if (event.button.x >=250 && event.button.x <=550 && event.button.y>=427 && event.button.y <=513)
					{
						fprintf( stdout,"\nNiv 3");
						SDL_HideWindow(niveau);
						SDL_ShowWindow(Niveau3);
						Fenetre_Niveau3(FondEcran_niveau3);
					}
				}
				
				if(event.button.windowID == 5)//Niveau1(fenetre)
				{
					//MENU
					if (event.button.x >=50 && event.button.x <=300 && event.button.y>=50 && event.button.y <=121)
					{
						fprintf( stdout,"\nMENU");
						fin=0;
						score=0;
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\gagnerNoir.bmp"),270,390,535,117);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\nivNoir.bmp"),700,715,300,86);
						SDL_HideWindow(Niveau1);
						SDL_ShowWindow(accueil);
						Fenetre_accueil(FondEcran_accueil);
					}
					
					//Piece 1
					if(event.button.x >=365 && event.button.x <=531 && event.button.y>=70 && event.button.y <=175)
					{
						fprintf(stdout,"\nPiece 1");
						piece1++;
						score++;
					}
					//Case 1
					if(event.button.x >=298 && event.button.x <=464 && event.button.y>=276 && event.button.y <=381)
					{
						fprintf(stdout,"\nCase 1");
						piece1++;
						if (piece1==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),365,70,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc1.bmp"),298,276,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 2
					if(event.button.x >=150 && event.button.x <=316 && event.button.y>=700 && event.button.y <=805)
					{
						fprintf(stdout,"\nPiece 2");
						piece2++;
						score++;
					}
					//Case 2
					if(event.button.x >=467 && event.button.x <=633 && event.button.y>=276 && event.button.y <=381)
					{
						fprintf(stdout,"\nCase 2");
						piece2++;
						if (piece2==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),150,700,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc2.bmp"),467,276,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 3
					if(event.button.x >=866 && event.button.x <=1032 && event.button.y>=340 && event.button.y <=445)
					{
						fprintf(stdout,"\nPiece 3");
						piece3++;
						score++;
					}
					//Case 3
					if(event.button.x >=636 && event.button.x <=802 && event.button.y>=276 && event.button.y <=381)
					{
						fprintf(stdout,"\nCase 3");
						piece3++;
						if (piece3==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),866,340,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc3.bmp"),636,276,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 4
					if(event.button.x >=750 && event.button.x <=916 && event.button.y>=740 && event.button.y <=845)
					{
						fprintf(stdout,"\nPiece 4");
						piece4++;
						score++;
					}
					//Case 4
					if(event.button.x >=298 && event.button.x <=464 && event.button.y>=384 && event.button.y <=489)
					{
						fprintf(stdout,"\nCase 4");
						piece4++;
						if (piece4==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),750,740,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc4.bmp"),298,384,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 5
					if(event.button.x >=585 && event.button.x <=751 && event.button.y>=90 && event.button.y <=195)
					{
						fprintf(stdout,"\nPiece 5");
						piece5++;
						score++;
					}
					//Case 5
					if(event.button.x >=467 && event.button.x <=633 && event.button.y>=384 && event.button.y <=489)
					{
						fprintf(stdout,"\nCase 5");
						piece5++;
						if (piece5==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),585,90,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc5.bmp"),467,384,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 6
					if(event.button.x >=66 && event.button.x <=232 && event.button.y>=225 && event.button.y <=330)
					{
						fprintf(stdout,"\nPiece 6");
						piece6++;
						score++;
					}
					//Case 6
					if(event.button.x >=636 && event.button.x <=802 && event.button.y>=384 && event.button.y <=489)
					{
						fprintf(stdout,"\nCase 6");
						piece6++;
						if (piece6==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),66,225,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc6.bmp"),636,384,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 7
					if(event.button.x >=66 && event.button.x <=232 && event.button.y>=445 && event.button.y <=550)
					{
						fprintf(stdout,"\nPiece 7");
						piece7++;
						score++;
					}
					//Case 7
					if(event.button.x >=298 && event.button.x <=464 && event.button.y>=492 && event.button.y <=597)
					{
						fprintf(stdout,"\nCase 7");
						piece7++;
						if (piece7==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),66,445,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc7.bmp"),298,492,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 8
					if(event.button.x >=450 && event.button.x <=616 && event.button.y>=660 && event.button.y <=765)
					{
						fprintf(stdout,"\nPiece 8");
						piece8++;
						score++;
					}
					//Case 8
					if(event.button.x >=467 && event.button.x <=633 && event.button.y>=492 && event.button.y <=597)
					{
						fprintf(stdout,"\nCase 8");
						piece8++;
						if (piece8==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),450,660,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc8.bmp"),467,492,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 9
					if(event.button.x >=866 && event.button.x <=1032 && event.button.y>=560 && event.button.y <=665)
					{
						fprintf(stdout,"\nPiece 9");
						piece9++;
						score++;
					}
					//Case 9
					if(event.button.x >=636 && event.button.x <=802 && event.button.y>=492 && event.button.y <=597)
					{
						fprintf(stdout,"\nCase 9");
						piece9++;
						if (piece9==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\rectnoir.bmp"),866,560,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\puzzle\\niv1\\pc9.bmp"),636,492,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					if(fin==9)
					{
						SDL_Delay(500);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\rectnoirNiv.bmp"),298,276,321,507);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\gagner.bmp"),270,390,535,117);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\Niv_2.bmp"),700,715,300,85);
						piece1=0;	piece2=0;	piece3=0;
						piece4=0;	piece5=0;	piece6=0;
						piece7=0;	piece8=0;	piece9=0;
						//Fscore(score);
						if(event.button.x >=700 && event.button.x <=1000 && event.button.y>=715 && event.button.y <=800)
						{
							fprintf(stdout,"\nNiv 2");
							fin=0;
							score=0;
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\gagnerNoir.bmp"),270,390,535,117);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\nivNoir.bmp"),700,715,300,86);
							SDL_HideWindow(Niveau1);
							SDL_ShowWindow(Niveau2);
							Fenetre_Niveau2(FondEcran_niveau2);
						}
					}
				}
				
				if(event.button.windowID == 6)//Niveau2(fenetre)
				{
					//MENU
					if (event.button.x >=50 && event.button.x <=300 && event.button.y>=50 && event.button.y <=121)
					{
						fprintf( stdout,"\nMENU");
						fin=0;
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\gagnerNoir.bmp"),270,390,535,117);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\fond\\nivNoir.bmp"),700,715,300,86);
						SDL_HideWindow(Niveau2);
						SDL_ShowWindow(accueil);
						Fenetre_accueil(FondEcran_accueil);
					}
					//Piece 1
					if(event.button.x >=350 && event.button.x <=474 && event.button.y>=660 && event.button.y <=740)
					{
						fprintf(stdout,"\nPiece 1");
						piece1++;
					}
					//Case 1
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 1");
						piece1++;
						if (piece1==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),347,657,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc1.bmp"),298,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 2
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=187 && event.button.y <=267)
					{
						fprintf(stdout,"\nPiece 2");
						piece2++;
					}
					//Case 2
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 2");
						piece2++;
						if (piece2==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),84,184,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc2.bmp"),425,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 3
					if(event.button.x >=600 && event.button.x <=724 && event.button.y>=165 && event.button.y <=245)
					{
						fprintf(stdout,"\nPiece 3");
						piece3++;
					}
					//Case 3
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 3");
						piece3++;
						if (piece3==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),597,162,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc3.bmp"),552,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 4
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=624 && event.button.y <=704)
					{
						fprintf(stdout,"\nPiece 4");
						piece4++;
					}
					//Case 4
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 4");
						piece4++;
						if (piece4==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),84,621,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc4.bmp"),679,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 5
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=479 && event.button.y <=559)
					{
						fprintf(stdout,"\nPiece 5");
						piece5++;
					}
					//Case 5
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 5");
						piece5++;
						if (piece5==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),84,476,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc5.bmp"),298,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 6
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=485 && event.button.y <=565)
					{
						fprintf(stdout,"\nPiece 6");
						piece6++;
					}
					//Case 6
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 6");
						piece6++;
						if (piece6==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),887,482,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc6.bmp"),425,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 7
					if(event.button.x >=650 && event.button.x <=774 && event.button.y>=30 && event.button.y <=110)
					{
						fprintf(stdout,"\nPiece 7");
						piece7++;
					}
					//Case 7
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 7");
						piece7++;
						if (piece7==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),647,27,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc7.bmp"),552,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 8
					if(event.button.x >=350 && event.button.x <=474 && event.button.y>=165 && event.button.y <=245)
					{
						fprintf(stdout,"\nPiece 8");
						piece8++;
					}
					//Case 8
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 8");
						piece8++;
						if (piece8==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),347,162,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc8.bmp"),679,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 9
					if(event.button.x >=400 && event.button.x <=525 && event.button.y>=30 && event.button.y <=110)
					{
						fprintf(stdout,"\nPiece 9");
						piece9++;
					}
					//Case 9
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 9");
						piece9++;
						if (piece9==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),397,27,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc9.bmp"),298,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 10
					if(event.button.x >=150 && event.button.x <=274 && event.button.y>=770 && event.button.y <=850)
					{
						fprintf(stdout,"\nPiece 10");
						piece10++;
					}
					//Case 10
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 10");
						piece10++;
						if (piece10==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),147,767,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc10.bmp"),425,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 11
					if(event.button.x >=750 && event.button.x <=874 && event.button.y>=740 && event.button.y <=820)
					{
						fprintf(stdout,"\nPiece 11");
						piece11++;
					}
					//Case 11
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 11");
						piece11++;
						if (piece11==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),747,737,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc11.bmp"),552,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 12
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=340 && event.button.y <=420)
					{
						fprintf(stdout,"\nPiece 12");
						piece12++;
					}
					//Case 12
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 12");
						piece12++;
						if (piece12==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),887,337,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc12.bmp"),679,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 13
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=195 && event.button.y <=275)
					{
						fprintf(stdout,"\nPiece 13");
						piece13++;
					}
					//Case 13
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 13");
						piece13++;
						if (piece13==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),887,192,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc13.bmp"),298,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 14
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=333 && event.button.y <=413)
					{
						fprintf(stdout,"\nPiece 14");
						piece14++;
					}
					//Case 14
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 14");
						piece14++;
						if (piece14==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),84,331,130,86);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc14.bmp"),425,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 15
					if(event.button.x >=900 && event.button.x <=1024 && event.button.y>=630 && event.button.y <=710)
					{
						fprintf(stdout,"\nPiece 15");
						piece15++;
					}
					//Case 15
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 15");
						piece15++;
						if (piece15==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),900,630,124,80);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc15.bmp"),552,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 16
					if(event.button.x >=550 && event.button.x <=674 && event.button.y>=700 && event.button.y <=780)
					{
						fprintf(stdout,"\nPiece 16");
						piece16++;
					}
					//Case 16
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 16");
						piece16++;
						if (piece16==2)
						{
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\rectnoir.bmp"),550,700,124,80);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\puzzle\\niv2\\pc16.bmp"),679,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					if(fin==16)
					{
						SDL_Delay(500);
						Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\fond\\rectnoirNiv.bmp"),298,286,321,507);
						Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\fond\\gagner.bmp"),270,390,535,117);
						Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\fond\\Niv_3.bmp"),700,714,300,86);
						if(event.button.x >=700 && event.button.x <=1000 && event.button.y>=714 && event.button.y <=800)
						{
							fprintf(stdout,"\nNiv 3");
							fin=0;
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\fond\\gagnerNoir.bmp"),270,390,535,117);
							Image(FondEcran_niveau2,SDL_LoadBMP(".\\img\\fond\\nivNoir.bmp"),700,715,300,86);
							SDL_HideWindow(Niveau2);
							SDL_ShowWindow(Niveau3);
							Fenetre_Niveau3(FondEcran_niveau3);
						}
					}
				}
				
				if(event.button.windowID == 7)//Niveau3(fenetre)
				{
					//MENU
					if (event.button.x >=50 && event.button.x <=300 && event.button.y>=50 && event.button.y <=121)
					{
						fprintf( stdout,"\nMENU");
						fin=0;
						Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\fond\\gagnerNoir.bmp"),270,390,535,117);
						SDL_HideWindow(Niveau3);
						SDL_ShowWindow(accueil);
						Fenetre_accueil(FondEcran_accueil);
					}
					//Piece 1
					if(event.button.x >=400 && event.button.x <=524 && event.button.y>=30 && event.button.y <=110)
					{
						fprintf(stdout,"\nPiece 1");
						piece1++;
					}
					//Case 1
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 1");
						piece1++;
						if (piece1==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),400,30,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc1.bmp"),298,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 2
					if(event.button.x >=150 && event.button.x <=274 && event.button.y>=770 && event.button.y <=850)
					{
						fprintf(stdout,"\nPiece 2");
						piece2++;
					}
					//Case 2
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 2");
						piece2++;
						if (piece2==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),150,770,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc2.bmp"),425,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 3
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=340 && event.button.y <=420)
					{
						fprintf(stdout,"\nPiece 3");
						piece3++;
					}
					//Case 3
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 3");
						piece3++;
						if (piece3==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),890,340,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc3.bmp"),552,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 4
					if(event.button.x >=750 && event.button.x <=874 && event.button.y>=740 && event.button.y <=820)
					{
						fprintf(stdout,"\nPiece 4");
						piece4++;
					}
					//Case 4
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 4");
						piece4++;
						if (piece4==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),750,740,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc4.bmp"),679,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 5
					if(event.button.x >=850 && event.button.x <=974 && event.button.y>=195 && event.button.y <=275)
					{
						fprintf(stdout,"\nPiece 5");
						piece5++;
					}
					//Case 5
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 5");
						piece5++;
						if (piece5==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),890,195,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc5.bmp"),298,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 6
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=624 && event.button.y <=704)
					{
						fprintf(stdout,"\nPiece 6");
						piece6++;
					}
					//Case 6
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 6");
						piece6++;
						if (piece6==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,624,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc6.bmp"),425,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 7
					if(event.button.x >=900 && event.button.x <=1024 && event.button.y>=630 && event.button.y <=710)
					{
						fprintf(stdout,"\nPiece 7");
						piece7++;
					}
					//Case 7
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 7");
						piece7++;
						if (piece7==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),900,630,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc7.bmp"),552,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 8
					if(event.button.x >=550 && event.button.x <=674 && event.button.y>=700 && event.button.y <=780)
					{
						fprintf(stdout,"\nPiece 8");
						piece8++;
					}
					//Case 8
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 8");
						piece8++;
						if (piece8==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),550,700,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc8.bmp"),679,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 9
					if(event.button.x >=350 && event.button.x <=474 && event.button.y>=660 && event.button.y <=740)
					{
						fprintf(stdout,"\nPiece 9");
						piece9++;
					}
					//Case 9
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 9");
						piece9++;
						if (piece9==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),350,660,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc9.bmp"),298,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 10
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=187 && event.button.y <=267)
					{
						fprintf(stdout,"\nPiece 10");
						piece10++;
					}
					//Case 10
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 10");
						piece10++;
						if (piece10==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,187,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc10.bmp"),425,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 11
					if(event.button.x >=600 && event.button.x <=724 && event.button.y>=100 && event.button.y <=180)
					{
						fprintf(stdout,"\nPiece 11");
						piece11++;
					}
					//Case 11
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 11");
						piece11++;
						if (piece11==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),600,100,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc11.bmp"),552,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 12
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=333 && event.button.y <=413)
					{
						fprintf(stdout,"\nPiece 12");
						piece12++;
					}
					//Case 12
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 12");
						piece12++;
						if (piece12==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,333,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc12.bmp"),679,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 13
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=479 && event.button.y <=559)
					{
						fprintf(stdout,"\nPiece 13");
						piece13++;
					}
					//Case 13
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 13");
						piece13++;
						if (piece13==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,479,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc13.bmp"),298,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 14
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=485 && event.button.y <=565)
					{
						fprintf(stdout,"\nPiece 14");
						piece14++;
					}
					//Case 14
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 14");
						piece14++;
						if (piece14==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),890,485,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc14.bmp"),425,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 15
					if(event.button.x >=800 && event.button.x <=924 && event.button.y>=50 && event.button.y <=130)
					{
						fprintf(stdout,"\nPiece 15");
						piece15++;
					}
					//Case 15
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 15");
						piece15++;
						if (piece15==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),800,50,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc15.bmp"),552,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 16
					if(event.button.x >=350 && event.button.x <=474 && event.button.y>=165 && event.button.y <=245)
					{
						fprintf(stdout,"\nPiece 16");
						piece16++;
					}
					//Case 16
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 16");
						piece16++;
						if (piece16==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),350,165,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc16.bmp"),679,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					if(fin==16)
					{
						SDL_Delay(500);
						Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\fond\\rectnoirNiv.bmp"),298,286,329,505);
						Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\fond\\gagner.bmp"),270,390,535,117);
						piece1=0;	piece2=0;	piece3=0;	piece4=0;
						piece5=0;	piece6=0;	piece7=0;	piece8=0;
						piece9=0;	piece10=0;	piece11=0;	piece12=0;
						piece13=0;	piece14=0;	piece15=0;	piece16=0;
					}
				}
			break;
			
			case SDL_WINDOWEVENT:
				if( event.window.event == SDL_WINDOWEVENT_CLOSE)
				{
					continuer=2;
				}
			break;
			default: ;
		}
	}
	Mix_CloseAudio();
	Mix_Quit();
	SDL_Quit();
	imgson=0;
    return 0; 
}