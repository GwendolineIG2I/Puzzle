#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_ttf.h>
#include <string.h>
#include <stdio.h>

void Image(SDL_Renderer *,SDL_Surface *,int ,int ,int ,int );
void Fenetre_regles(SDL_Renderer *);
//void Texte(SDL_Renderer *, char *, char *, int, int, int, int, int, int, int, int);


void Fenetre_regles(SDL_Renderer *FondEcran_regles)
{
	SDL_Surface *menu = NULL;
	SDL_Surface *bateau = NULL;
	SDL_Surface *pirate1 = NULL;
	SDL_Surface *pirate2 = NULL;
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	bateau=SDL_LoadBMP(".\\img\\fond\\bateau.bmp");
	pirate1=SDL_LoadBMP(".\\img\\fond\\pirate.bmp");
	pirate2=SDL_LoadBMP(".\\img\\fond\\pirate1.bmp");

	Image(FondEcran_regles,menu,50,50,250,71);		   
	Image(FondEcran_regles,bateau,500,20,200,192);
	Image(FondEcran_regles,pirate1,550,475,250,138);
	Image(FondEcran_regles,pirate2,0,475,250,166);
	Image(FondEcran_regles,SDL_LoadBMP(".\\img\\fond\\regles2.bmp"),103,257,593,185);
}
void Image(SDL_Renderer *FondEcran,SDL_Surface *pic,int x,int y,int largeur,int hauteur)
{
	SDL_Rect rect,rst;
	SDL_Texture *tex = NULL;
	
	
	tex = SDL_CreateTextureFromSurface(FondEcran, pic);
	SDL_FreeSurface(pic);
	rect.x = x;//position de l'image en x sur la fenetre
	rect.y = y;//position de l'image en y sur la fenetre
	
	if ( SDL_QueryTexture(tex, NULL, NULL, &rect.w, &rect.h)<0 )
		fprintf(stdout,"error QueryTexture");

	rst.x=0; // pour afficher l'image à partir de son abscisse x=0
	rst.y=0; // pour afficher l'image à partir de son ordonnee y=0
	rst.w=largeur;
	rst.h=hauteur;
		
	if (SDL_RenderCopy(FondEcran, tex, &rst, &rect)<0)
		 fprintf( stdout,"\nprobleme rendercopy ;-)) ");
	else fprintf( stdout,"\nrender 		 OK ;-)) ");
				   
	SDL_RenderPresent(FondEcran);//on pose  sur la fenetre
}
/*
void Texte(SDL_Renderer *FondEcran, char *refPolice, char *texte, int red, int green, int blue, int taille, int x, int y, int h, int w)
{
    TTF_Font *police;
    police = TTF_OpenFont(refPolice,taille);
    SDL_Color couleur = {red,green,blue};
    SDL_Surface* surface_texte = NULL;
    surface_texte = TTF_RenderText_Blended(police,texte,couleur);
    SDL_Texture* texture_texte = SDL_CreateTextureFromSurface(FondEcran,surface_texte);
    SDL_Rect position = {x,y,h,w};
    SDL_RenderCopy(FondEcran,texture_texte,NULL,&position);
    SDL_RenderPresent(FondEcran);
}

*/

int main(int argc, char** argv)
{
	fprintf(stdout,"argc=%d",argc);
	fprintf(stdout,"argv=%s",argv[0]);
	if (SDL_Init(SDL_INIT_VIDEO) != 0 )
    {
        fprintf(stdout,"Échec de l'initialisation de la SDL (%s)\n",SDL_GetError());
        return -1;
    }
	
	if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, MIX_DEFAULT_CHANNELS, 1024) == -1) //Initialisation de l'API Mixer
    {
      fprintf(stdout, "\nEreur d'initialisation de SDL2 MIXER : %s", Mix_GetError());
      SDL_Quit();
      return -2;

	} 
	SDL_Window *regles = NULL;
	SDL_Renderer *FondEcran_regles = NULL;
	
	
	
	
	
	regles=SDL_CreateWindow("Règles du jeu",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							 800,
							 700,
							 SDL_WINDOW_SHOWN); 
	FondEcran_regles = SDL_CreateRenderer(regles, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
	
	
	
	Fenetre_regles(FondEcran_regles);
	
	SDL_Delay(4000);
	return 0;
}