#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <string.h>
#include <stdio.h>

void Fenetre_Niveau1(SDL_Renderer *);
void Image(SDL_Renderer *,SDL_Surface *,int ,int ,int ,int );
SDL_Event event;
/*****/

void Fenetre_Niveau1(SDL_Renderer *FondEcran_niveau1)
{
	SDL_Surface *menu = NULL,*piece1 = NULL,*piece2 = NULL,*piece3 = NULL,*piece4 = NULL,*piece5 = NULL,*piece6 = NULL,*piece7 = NULL,*piece8 = NULL,*piece9 = NULL;
	menu=SDL_LoadBMP(".\\img\\Menu.bmp");
	piece1=SDL_LoadBMP(".\\img\\pc1.bmp");
	piece2=SDL_LoadBMP(".\\img\\pc2.bmp");
	piece3=SDL_LoadBMP(".\\img\\pc3.bmp");
	piece4=SDL_LoadBMP(".\\img\\pc4.bmp");
	piece5=SDL_LoadBMP(".\\img\\pc5.bmp");
	piece6=SDL_LoadBMP(".\\img\\pc6.bmp");
	piece7=SDL_LoadBMP(".\\img\\pc7.bmp");
	piece8=SDL_LoadBMP(".\\img\\pc8.bmp");
	piece9=SDL_LoadBMP(".\\img\\pc9.bmp");
	
	Image(FondEcran_niveau1,menu,50,50,250,71);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rect2.bmp"),824,23,253,161);
	Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\reponse1.bmp"),826,25,249,157);
	Image(FondEcran_niveau1,piece1,365,70,166,105);
	Image(FondEcran_niveau1,piece2,150,700,166,105);
	Image(FondEcran_niveau1,piece3,866,340,166,105);
	Image(FondEcran_niveau1,piece4,750,740,166,105);
	Image(FondEcran_niveau1,piece5,585,90,166,105);
	Image(FondEcran_niveau1,piece6,66,225,166,105);
	Image(FondEcran_niveau1,piece7,66,445,166,105);
	Image(FondEcran_niveau1,piece8,450,660,166,105);
	Image(FondEcran_niveau1,piece9,866,560,166,105);
	
	
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),298,276,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),467,276,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),636,276,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),298,384,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),467,384,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),636,384,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),298,492,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),467,492,166,105);
	Image(FondEcran_niveau1,SDL_LoadBMP("./img/rect.bmp"),636,492,166,105);

	
	
	
	
	
	
}

void Image(SDL_Renderer *FondEcran,SDL_Surface *pic,int x,int y,int largeur,int hauteur)
{
	SDL_Rect rect,rst;
	SDL_Texture *tex = NULL;
	
	
	tex = SDL_CreateTextureFromSurface(FondEcran, pic);
	SDL_FreeSurface(pic);
	rect.x = x;//position de l'image en x sur la fenetre
	rect.y = y;//position de l'image en y sur la fenetre
	
	if ( SDL_QueryTexture(tex, NULL, NULL, &rect.w, &rect.h)<0 )
		fprintf(stdout,"error QueryTexture");

	rst.x=0; // pour afficher l'image à partir de son abscisse x=0
	rst.y=0; // pour afficher l'image à partir de son ordonnee y=0
	rst.w=largeur;
	rst.h=hauteur;
		
	if (SDL_RenderCopy(FondEcran, tex, &rst, &rect)<0)
		 fprintf( stdout,"\nprobleme rendercopy ;-)) ");
	else fprintf( stdout,"\nrender 		 OK ;-)) ");
				   
	SDL_RenderPresent(FondEcran);//on pose  sur la fenetre
}

/******************************************************************************/
int main(int argc, char** argv)
{
	int continuer=1,piece1=0,piece2=0,piece3=0,piece4=0,piece5=0,piece6=0,piece7=0,piece8=0,piece9=0,fin=0;
	SDL_Window *Niveau1 = NULL;
	SDL_Renderer *FondEcran_niveau1=NULL;
	
	fprintf(stdout,"argc=%d",argc);
	fprintf(stdout,"argv=%s",argv[0]);
	if (SDL_Init(SDL_INIT_VIDEO) != 0 )
    {
        fprintf(stdout,"Échec de l'initialisation de la SDL (%s)\n",SDL_GetError());
        return -1;
    }
	/******** Déclaration des fenêtres ********/
	Niveau1=SDL_CreateWindow("Puzzle Niveau 1",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  1100,
							  900,
							  SDL_WINDOW_SHOWN);
							
	
	
	FondEcran_niveau1 = SDL_CreateRenderer(Niveau1, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
		
	
    Fenetre_Niveau1(FondEcran_niveau1);
	while(continuer==1)
	{
		SDL_WaitEvent(&event);
		switch (event.type) /* Quel événement avons-nous ? */
        {	
			case SDL_MOUSEBUTTONDOWN:
				if(event.button.windowID == 1)//Niveau1(fenetre)
				{
					//Piece 1
					if(event.button.x >=365 && event.button.x <=531 && event.button.y>=70 && event.button.y <=175)
					{
						fprintf(stdout,"\nPiece 1");
						piece1++;
						printf("\n1=%d",piece1);
					}
					//Case 1
					if(event.button.x >=298 && event.button.x <=464 && event.button.y>=276 && event.button.y <=381)
					{
						fprintf(stdout,"\nCase 1");
						piece1++;
						printf("\n1=%d",piece1);
						if (piece1==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),365,70,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc1.bmp"),298,276,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 2
					if(event.button.x >=150 && event.button.x <=316 && event.button.y>=700 && event.button.y <=805)
					{
						fprintf(stdout,"\nPiece 2");
						piece2++;
						printf("\n2=%d",piece2);
					}
					//Case 2
					if(event.button.x >=467 && event.button.x <=633 && event.button.y>=276 && event.button.y <=381)
					{
						fprintf(stdout,"\nCase 2");
						piece2++;
						printf("\n2=%d",piece2);
						if (piece2==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),150,700,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc2.bmp"),467,276,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 3
					if(event.button.x >=866 && event.button.x <=1032 && event.button.y>=340 && event.button.y <=445)
					{
						fprintf(stdout,"\nPiece 3");
						piece3++;
						printf("\n3=%d",piece3);
					}
					//Case 3
					if(event.button.x >=636 && event.button.x <=802 && event.button.y>=276 && event.button.y <=381)
					{
						fprintf(stdout,"\nCase 3");
						piece3++;
						printf("\n3=%d",piece3);
						if (piece3==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),866,340,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc3.bmp"),636,276,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 4
					if(event.button.x >=750 && event.button.x <=916 && event.button.y>=740 && event.button.y <=845)
					{
						fprintf(stdout,"\nPiece 4");
						piece4++;
						printf("\n4=%d",piece4);
					}
					//Case 4
					if(event.button.x >=298 && event.button.x <=464 && event.button.y>=384 && event.button.y <=489)
					{
						fprintf(stdout,"\nCase 4");
						piece4++;
						printf("\n4=%d",piece4);
						if (piece4==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),750,740,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc4.bmp"),298,384,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 5
					if(event.button.x >=585 && event.button.x <=751 && event.button.y>=90 && event.button.y <=195)
					{
						fprintf(stdout,"\nPiece 5");
						piece5++;
						printf("\n5=%d",piece5);
					}
					//Case 5
					if(event.button.x >=467 && event.button.x <=633 && event.button.y>=384 && event.button.y <=489)
					{
						fprintf(stdout,"\nCase 5");
						piece5++;
						printf("\n5=%d",piece5);
						if (piece5==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),585,90,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc5.bmp"),467,384,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 6
					if(event.button.x >=66 && event.button.x <=232 && event.button.y>=225 && event.button.y <=330)
					{
						fprintf(stdout,"\nPiece 6");
						piece6++;
						printf("\n6=%d",piece6);
					}
					//Case 6
					if(event.button.x >=636 && event.button.x <=802 && event.button.y>=384 && event.button.y <=489)
					{
						fprintf(stdout,"\nCase 6");
						piece6++;
						printf("\n6=%d",piece6);
						if (piece6==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),66,225,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc6.bmp"),636,384,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 7
					if(event.button.x >=66 && event.button.x <=232 && event.button.y>=445 && event.button.y <=550)
					{
						fprintf(stdout,"\nPiece 7");
						piece7++;
						printf("\n7=%d",piece7);
					}
					//Case 7
					if(event.button.x >=298 && event.button.x <=464 && event.button.y>=492 && event.button.y <=597)
					{
						fprintf(stdout,"\nCase 7");
						piece7++;
						printf("\n7=%d",piece7);
						if (piece7==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),66,445,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc7.bmp"),298,492,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					//Piece 8
					if(event.button.x >=450 && event.button.x <=616 && event.button.y>=660 && event.button.y <=765)
					{
						fprintf(stdout,"\nPiece 8");
						piece8++;
						printf("\n8=%d",piece8);
					}
					//Case 8
					if(event.button.x >=467 && event.button.x <=633 && event.button.y>=492 && event.button.y <=597)
					{
						fprintf(stdout,"\nCase 8");
						piece8++;
						printf("\n8=%d",piece8);
						if (piece8==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),450,660,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc8.bmp"),467,492,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					
					
					//Piece 9
					if(event.button.x >=866 && event.button.x <=1032 && event.button.y>=560 && event.button.y <=665)
					{
						fprintf(stdout,"\nPiece 9");
						piece9++;
						printf("\n9=%d",piece9);
					}
					//Case 9
					if(event.button.x >=636 && event.button.x <=802 && event.button.y>=492 && event.button.y <=597)
					{
						fprintf(stdout,"\nCase 9");
						piece9++;
						printf("\n9=%d",piece9);
						if (piece9==2)
						{
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir.bmp"),866,560,166,105);
							Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\pc9.bmp"),636,492,166,105);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;
							piece4=0;	piece5=0;	piece6=0;
							piece7=0;	piece8=0;	piece9=0;
						}
					}
					if(fin==9)
					{
						SDL_Delay(500);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\rectnoir2.bmp"),298,276,321,507);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\gagner.bmp"),270,390,535,117);
						Image(FondEcran_niveau1,SDL_LoadBMP(".\\img\\Niv_2.bmp"),700,715,300,85);
					}
				}
			break;
			
			case SDL_WINDOWEVENT:
				if( event.window.event == SDL_WINDOWEVENT_CLOSE)
				{
					continuer=2;
				}
			break;
			default: ;
		}
	}
	SDL_Quit();
    return 0; 
}