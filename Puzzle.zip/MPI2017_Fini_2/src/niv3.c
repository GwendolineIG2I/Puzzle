#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <string.h>
#include <stdio.h>

void Fenetre_Niveau3(SDL_Renderer *);
void Image(SDL_Renderer *,SDL_Surface *,int ,int ,int ,int );
SDL_Event event;
/*****/

void Fenetre_Niveau3(SDL_Renderer *FondEcran_niveau3)
{
	SDL_Surface *menu = NULL;
	menu=SDL_LoadBMP(".\\img\\fond\\Menu.bmp");
	
	Image(FondEcran_niveau3,menu,50,50,250,71);
	//Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectniv3.bmp"),831,23,246,161);
	//Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\reponse3.bmp"),833,25,242,157);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc1.bmp"),400,30,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc2.bmp"),150,770,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc3.bmp"),890,340,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc4.bmp"),750,740,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc5.bmp"),890,195,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc6.bmp"),87,624,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc7.bmp"),900,630,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc8.bmp"),550,700,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc9.bmp"),350,660,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc10.bmp"),87,187,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc11.bmp"),600,100,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc12.bmp"),87,333,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc13.bmp"),87,479,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc14.bmp"),890,485,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc15.bmp"),800,50,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc16.bmp"),350,165,124,80);
	
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,286,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,286,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,286,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,286,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,369,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,369,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,369,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,369,124,80);
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,452,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,452,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,452,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,452,124,80);	
	
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),298,535,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),425,535,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),552,535,124,80);
	Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rect.bmp"),679,535,124,80);	
	
	
	
	
}

void Image(SDL_Renderer *FondEcran,SDL_Surface *pic,int x,int y,int largeur,int hauteur)
{
	SDL_Rect rect,rst;
	SDL_Texture *tex = NULL;
	
	
	tex = SDL_CreateTextureFromSurface(FondEcran, pic);
	SDL_FreeSurface(pic);
	rect.x = x;//position de l'image en x sur la fenetre
	rect.y = y;//position de l'image en y sur la fenetre
	
	if ( SDL_QueryTexture(tex, NULL, NULL, &rect.w, &rect.h)<0 )
		fprintf(stdout,"error QueryTexture");

	rst.x=0; // pour afficher l'image à partir de son abscisse x=0
	rst.y=0; // pour afficher l'image à partir de son ordonnee y=0
	rst.w=largeur;
	rst.h=hauteur;
		
	if (SDL_RenderCopy(FondEcran, tex, &rst, &rect)<0)
		 fprintf( stdout,"\nprobleme rendercopy ;-)) ");
	else fprintf( stdout,"\nrender 		 OK ;-)) ");
				   
	SDL_RenderPresent(FondEcran);//on pose  sur la fenetre
}

/******************************************************************************/
int main(int argc, char** argv)
{
	int continuer=1,piece1=0,piece2=0,piece3=0,piece4=0,piece5=0,piece6=0,piece7=0,piece8=0,piece9=0,piece10=0,piece11=0,piece12=0,piece13=0,piece14=0,piece15=0,piece16=0,fin=0;
	SDL_Window *Niveau3 = NULL;
	SDL_Renderer *FondEcran_niveau3=NULL;
	
	fprintf(stdout,"argc=%d",argc);
	fprintf(stdout,"argv=%s",argv[0]);
	if (SDL_Init(SDL_INIT_VIDEO) != 0 )
    {
        fprintf(stdout,"Échec de l'initialisation de la SDL (%s)\n",SDL_GetError());
        return -1;
    }
	/******** Déclaration des fenêtres ********/
	Niveau3=SDL_CreateWindow("Puzzle Niveau 3",SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  SDL_WINDOWPOS_CENTERED, // met au centre la fenetre
							  1100,
							  900,
							  SDL_WINDOW_SHOWN);
							
	
	
	FondEcran_niveau3 = SDL_CreateRenderer(Niveau3, -1, SDL_RENDERER_ACCELERATED ); //  SDL_RENDERER_SOFTWARE 
		
	
    Fenetre_Niveau3(FondEcran_niveau3);
	while(continuer==1)
	{
		SDL_WaitEvent(&event);
		switch (event.type) /* Quel événement avons-nous ? */
        {	
			case SDL_MOUSEBUTTONDOWN:
				if(event.button.windowID == 1)//Niveau3(fenetre)
				{
					
					//Piece 1
					if(event.button.x >=400 && event.button.x <=524 && event.button.y>=30 && event.button.y <=110)
					{
						fprintf(stdout,"\nPiece 1");
						piece1++;
						printf("\n1=%d",piece1);
					}
					//Case 1
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 1");
						piece1++;
						printf("\n1=%d",piece1);
						if (piece1==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),400,30,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc1.bmp"),298,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 2
					if(event.button.x >=150 && event.button.x <=274 && event.button.y>=770 && event.button.y <=850)
					{
						fprintf(stdout,"\nPiece 2");
						piece2++;
						printf("\n2=%d",piece2);
					}
					//Case 2
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 2");
						piece2++;
						printf("\n2=%d",piece2);
						if (piece2==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),150,770,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc2.bmp"),425,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 3
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=340 && event.button.y <=420)
					{
						fprintf(stdout,"\nPiece 3");
						piece3++;
						printf("\n3=%d",piece3);
					}
					//Case 3
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 3");
						piece3++;
						printf("\n3=%d",piece3);
						if (piece3==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),890,340,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc3.bmp"),552,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 4
					if(event.button.x >=750 && event.button.x <=874 && event.button.y>=740 && event.button.y <=820)
					{
						fprintf(stdout,"\nPiece 4");
						piece4++;
						printf("\n4=%d",piece4);
					}
					//Case 4
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=286 && event.button.y <=366)
					{
						fprintf(stdout,"\nCase 4");
						piece4++;
						printf("\n4=%d",piece4);
						if (piece4==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),750,740,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc4.bmp"),679,286,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 5
					if(event.button.x >=850 && event.button.x <=974 && event.button.y>=195 && event.button.y <=275)
					{
						fprintf(stdout,"\nPiece 5");
						piece5++;
						printf("\n5=%d",piece5);
					}
					//Case 5
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 5");
						piece5++;
						printf("\n5=%d",piece5);
						if (piece5==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),890,195,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc5.bmp"),298,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 6
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=624 && event.button.y <=704)
					{
						fprintf(stdout,"\nPiece 6");
						piece6++;
						printf("\n6=%d",piece6);
					}
					//Case 6
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 6");
						piece6++;
						printf("\n6=%d",piece6);
						if (piece6==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,624,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc6.bmp"),425,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 7
					if(event.button.x >=900 && event.button.x <=1024 && event.button.y>=630 && event.button.y <=710)
					{
						fprintf(stdout,"\nPiece 7");
						piece7++;
						printf("\n7=%d",piece7);
					}
					//Case 7
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 7");
						piece7++;
						printf("\n7=%d",piece7);
						if (piece7==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),900,630,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc7.bmp"),552,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 8
					if(event.button.x >=550 && event.button.x <=674 && event.button.y>=700 && event.button.y <=780)
					{
						fprintf(stdout,"\nPiece 8");
						piece8++;
						printf("\n8=%d",piece8);
					}
					//Case 8
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=369 && event.button.y <=449)
					{
						fprintf(stdout,"\nCase 8");
						piece8++;
						printf("\n8=%d",piece8);
						if (piece8==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),550,700,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc8.bmp"),679,369,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 9
					if(event.button.x >=350 && event.button.x <=474 && event.button.y>=660 && event.button.y <=740)
					{
						fprintf(stdout,"\nPiece 9");
						piece9++;
						printf("\n9=%d",piece9);
					}
					//Case 9
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 9");
						piece9++;
						printf("\n9=%d",piece9);
						if (piece9==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),350,660,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc9.bmp"),298,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 10
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=187 && event.button.y <=267)
					{
						fprintf(stdout,"\nPiece 10");
						piece10++;
						printf("\n10=%d",piece10);
					}
					//Case 10
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 10");
						piece10++;
						printf("\n10=%d",piece10);
						if (piece10==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,187,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc10.bmp"),425,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 11
					if(event.button.x >=600 && event.button.x <=724 && event.button.y>=100 && event.button.y <=180)
					{
						fprintf(stdout,"\nPiece 11");
						piece11++;
						printf("\n11=%d",piece11);
					}
					//Case 11
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 11");
						piece11++;
						printf("\n11=%d",piece11);
						if (piece11==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),600,100,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc11.bmp"),552,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 12
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=333 && event.button.y <=413)
					{
						fprintf(stdout,"\nPiece 12");
						piece12++;
						printf("\n12=%d",piece12);
					}
					//Case 12
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=452 && event.button.y <=532)
					{
						fprintf(stdout,"\nCase 12");
						piece12++;
						printf("\n12=%d",piece12);
						if (piece12==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,333,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc12.bmp"),679,452,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 13
					if(event.button.x >=87 && event.button.x <=211 && event.button.y>=479 && event.button.y <=559)
					{
						fprintf(stdout,"\nPiece 13");
						piece13++;
						printf("\n13=%d",piece13);
					}
					//Case 13
					if(event.button.x >=298 && event.button.x <=422 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 13");
						piece13++;
						printf("\n13=%d",piece13);
						if (piece13==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),87,479,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc13.bmp"),298,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					//Piece 14
					if(event.button.x >=890 && event.button.x <=1014 && event.button.y>=485 && event.button.y <=565)
					{
						fprintf(stdout,"\nPiece 14");
						piece14++;
						printf("\n14=%d",piece14);
					}
					//Case 14
					if(event.button.x >=425 && event.button.x <=549 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 14");
						piece14++;
						printf("\n14=%d",piece14);
						if (piece14==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),890,485,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc14.bmp"),425,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 15
					if(event.button.x >=800 && event.button.x <=924 && event.button.y>=50 && event.button.y <=130)
					{
						fprintf(stdout,"\nPiece 15");
						piece15++;
						printf("\n15=%d",piece15);
					}
					//Case 15
					if(event.button.x >=552 && event.button.x <=676 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 15");
						piece15++;
						printf("\n15=%d",piece15);
						if (piece15==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),800,50,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc15.bmp"),552,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					//Piece 16
					if(event.button.x >=350 && event.button.x <=474 && event.button.y>=165 && event.button.y <=245)
					{
						fprintf(stdout,"\nPiece 16");
						piece16++;
						printf("\n16=%d",piece16);
					}
					//Case 16
					if(event.button.x >=679 && event.button.x <=803 && event.button.y>=535 && event.button.y <=615)
					{
						fprintf(stdout,"\nCase 16");
						piece16++;
						printf("\n16=%d",piece16);
						if (piece16==2)
						{
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\rectnoir.bmp"),350,165,124,80);
							Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\puzzle\\niv3\\pc16.bmp"),679,535,124,80);
							fin++;
						}
						else
						{
							piece1=0;	piece2=0;	piece3=0;	piece4=0;
							piece5=0;	piece6=0;	piece7=0;	piece8=0;
							piece9=0;	piece10=0;	piece11=0;	piece12=0;
							piece13=0;	piece14=0;	piece15=0;	piece16=0;
						}
					}
					
					if(fin==16)
					{
						SDL_Delay(500);
						Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\fond\\rectnoirNiv.bmp"),298,286,329,505);
						Image(FondEcran_niveau3,SDL_LoadBMP(".\\img\\fond\\gagner.bmp"),270,390,535,117);
						piece1=0;	piece2=0;	piece3=0;	piece4=0;
						piece5=0;	piece6=0;	piece7=0;	piece8=0;
						piece9=0;	piece10=0;	piece11=0;	piece12=0;
						piece13=0;	piece14=0;	piece15=0;	piece16=0;
					}
				}
			break;
			
			case SDL_WINDOWEVENT:
				if( event.window.event == SDL_WINDOWEVENT_CLOSE)
				{
					continuer=2;
				}
			break;
			default: ;
		}
	}
	SDL_Quit();
    return 0; 
}